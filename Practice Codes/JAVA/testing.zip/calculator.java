import java.awt.*;
import java.awt.event.*;
class calculator extends WindowAdapter implements ActionListener
{
	//Variables
	int point=0,res=0,op_index=0,num_index=0,num1=0,num2=0;
	
	//int ractive=0,n1active=0,n2active=0,opactive=0,inc=0,lng=0,n_op=0,opi_c,numi_c;
	
	String val="";
	int num[]=new int[100];
	char operator[]=new char[100];
	
	//Frame object
	Frame f=new Frame();
	
	//Text Box objects
	TextField t1=new TextField(255);
	
	//function Buttons 
	Button bce=new Button("CE");
	Button bc=new Button("C");
	Button bba=new Button("Del");
	Button b1x=new Button("1/x");
	Button bx2=new Button("x^2");
	Button b2x=new Button("sqrt x");
	
	//Number Buttons
	Button b0=new Button("0");
	Button b1=new Button("1");
	Button b2=new Button("2");
	Button b3=new Button("3");
	Button b4=new Button("4");
	Button b5=new Button("5");
	Button b6=new Button("6");
	Button b7=new Button("7");
	Button b8=new Button("8");
	Button b9=new Button("9");
	Button bp=new Button(".");
	Button bnp=new Button("+/-");
	
	//Operator Buttons
	Button badd=new Button("+");
	Button bsub=new Button("-");
	Button bmul=new Button("X");
	Button bdiv=new Button("/");
	Button bres=new Button("=");
	Button bper=new Button("%");
	
	void Cal_UI()
	{
		//Text Box edits
		t1.setBounds(25,45,255,44);
		
		//Button Layer 1
		bper.setBounds(25,110,62,40);
			bper.addActionListener(this);
		bce.setBounds(87,110,62,40);
			bce.addActionListener(this);
		bc.setBounds(149,110,62,40);
			bc.addActionListener(this);
		bba.setBounds(211,110,62,40);
			bba.addActionListener(this);
		
		//Button Layer 2
		b1x.setBounds(25,150,62,40);
			b1x.addActionListener(this);
		bx2.setBounds(87,150,62,40);
			bx2.addActionListener(this);
		b2x.setBounds(149,150,62,40);
			b2x.addActionListener(this);
		bdiv.setBounds(211,150,62,40);
			bdiv.addActionListener(this);
		
		//Button Layer 3
		b7.setBounds(25,190,62,40);
			b7.addActionListener(this);
		b8.setBounds(87,190,62,40);
			b8.addActionListener(this);
		b9.setBounds(149,190,62,40);
			b9.addActionListener(this);
		bmul.setBounds(211,190,62,40);
			bmul.addActionListener(this);
		
		//Button Layer 4
		b4.setBounds(25,230,62,40);
			b4.addActionListener(this);
		b5.setBounds(87,230,62,40);
			b5.addActionListener(this);
		b6.setBounds(149,230,62,40);
			b6.addActionListener(this);
		bsub.setBounds(211,230,62,40);
			bsub.addActionListener(this);
		
		//Button Layer 5
		b1.setBounds(25,270,62,40);
			b1.addActionListener(this);
		b2.setBounds(87,270,62,40);
			b2.addActionListener(this);
		b3.setBounds(149,270,62,40);
			b3.addActionListener(this);
		badd.setBounds(211,270,62,40);
			badd.addActionListener(this);
		
		//Button Layer 6
		bnp.setBounds(25,310,62,40);
			bnp.addActionListener(this);
		b0.setBounds(87,310,62,40);
			b0.addActionListener(this);
		bp.setBounds(149,310,62,40);
			bp.addActionListener(this);
		bres.setBounds(211,310,62,40);
			bres.addActionListener(this);
		
		//Frame addings
		f.add(t1);
		f.add(bper);
		f.add(bce);
		f.add(bc);
		f.add(bba);
		f.add(b1x);
		f.add(bx2);
		f.add(b2x);
		f.add(bdiv);
		f.add(b7);
		f.add(b8);
		f.add(b9);
		f.add(bmul);
		f.add(b4);
		f.add(b5);
		f.add(b6);
		f.add(bsub);
		f.add(b1);
		f.add(b2);
		f.add(b3);
		f.add(badd);
		f.add(bnp);
		f.add(b0);
		f.add(bp);
		f.add(bres);
		
		//Frame controls
		f.addWindowListener(this);
		f.setLayout(null);
		f.setSize(301,390);
		f.setTitle("Calculator");
		f.setVisible(true);
	}
	
	public void windowClosing(WindowEvent e)
	{
		f.dispose();
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		
		if(ae.getSource()==b0)
		{
			val=val+"0";
			t1.setText(val);
			System.out.print("0");
		}
		
		if(ae.getSource()==b1)
		{
			val=val+"1";
			t1.setText(val);
			System.out.print("1");
		}
		
		if(ae.getSource()==b2)
		{
			val=val+"2";
			t1.setText(val);
			System.out.print("2");
		}
		
		if(ae.getSource()==b3)
		{
			val=val+"3";
			t1.setText(val);
			System.out.print("3");
		}
		
		if(ae.getSource()==b4)
		{
			val=val+"4";
			t1.setText(val);
			System.out.print("4");
		}
		
		if(ae.getSource()==b5)
		{
			val=val+"5";
			t1.setText(val);
			System.out.print("5");
		}
		
		if(ae.getSource()==b6)
		{
			val=val+"6";
			t1.setText(val);
			System.out.print("6");
		}
		
		if(ae.getSource()==b7)
		{
			val=val+"7";
			t1.setText(val);
			System.out.print("7");
		}
		
		if(ae.getSource()==b8)
		{
			val=val+"8";
			t1.setText(val);
			System.out.print("8");
		}
		
		if(ae.getSource()==b9)
		{
			val=val+"9";
			t1.setText(val);
			System.out.print("9");
		}
		
		if(ae.getSource()==bp)
		{
			if(point==0)
			{
				val=val+".";
				t1.setText(val);
				point++;
			}
		}
		
		if(ae.getSource()==badd)
		{
			num[num_index]=Integer.parseInt(val);
			num_index++;
			val=val+"+";
			t1.setText(val);
			val="";
			operator[op_index]='+';
			System.out.println("\n+");
			op_index++;
		}
		
		if(ae.getSource()==bsub)
		{
			num[num_index]=Integer.parseInt(val);
			num_index++;
			val=val+"-";
			t1.setText(val);
			val="";
			operator[op_index]='-';
			System.out.println("\n-");
			op_index++;
		}
		
		if(ae.getSource()==bmul)
		{
			num[num_index]=Integer.parseInt(val);
			num_index++;
			val=val+"*";
			t1.setText(val);
			val="";
			operator[op_index]='*';
			System.out.println("\n*");
			op_index++;
		}
		
		if(ae.getSource()==bdiv)
		{
			num[num_index]=Integer.parseInt(val);
			num_index++;
			val=val+"/";
			t1.setText(val);
			val="";
			operator[op_index]='/';
			System.out.println("\n/");
			op_index++;
		}
		
		if(ae.getSource()==bc)
		{
			val="";
			t1.setText("0");
			System.out.println("Clear Screen");
		}
		
		if(ae.getSource()==bce)
		{
			point=0;
			res=0;
			op_index=0;
			num_index=0;
			num1=0;
			num2=0;
			val="";
			t1.setText("0");
			System.out.println("Memory Clear");
		}
		
		if(ae.getSource()==bres)
		{
			num[num_index]=Integer.parseInt(val);
			num_index++;
			System.out.println("\n\nArray Display");
			for(int m=0;m<num_index;m++)
			{
				System.out.println(num[m]);
			}
			
			for(int j=0;j<op_index;j++)
			{
				System.out.println(operator[j]);
			}
			
			for(int i=0;i<op_index;i++)
			{
				
				if(i==0)
				{
					num1=num[0];
					num2=num[1];
					
					switch(operator[i])
					{
						case '+':
							res=num1+num2;
							System.out.println("not else"+res);
							break;
						
						case '-':
							res=num1-num2;
							System.out.println("not else"+res);
							break;
						
						case '*':
							res=num1*num2;
							System.out.println("not else"+res);
							break;
						
						case '/':
							res=num1/num2;
							System.out.println("not else"+res);
							break;
						
						default:
							break;
					}
				}
				else
				{
					num2=num[i+1];
					
					switch(operator[i])
					{
						case '+':
							res=res+num2;
							System.out.println("else part"+res);
							break;
						
						case '-':
							res=res-num2;
							System.out.println("else part"+res);
							break;
						
						case '*':
							res=res*num2;
							System.out.println("else part"+res);
							break;
						
						case '/':
							res=res/num2;
							System.out.println("else part"+res);
							break;
						
						default:
							break;
					}
				}
			}
			t1.setText(String.valueOf(res));
		}
	}
	
	public static void main(String args[])
	{
		calculator ob=new calculator();
		ob.Cal_UI();
	}
}