import java.util.Scanner;

public class test0607 {
    static Scanner sc=new Scanner(System.in);
    public static void main(String args[]){
// no. of rows = no. of columns...
        int mat1[][]=new int[3][3];  

/*      { 
            { 1, 2, 3 }, i=0
            { 4, 5, 6 }, i=1
            { 7, 8, 9 }  i=2
        }  
*/

        for (int i=0;i<3;i++) // accessing all the rows ...
        {                       // mat1[i] is an array 
            for(int j=0;j<3;j++) //accessing all the columns...
            {
                mat1[i][j]=sc.nextInt();    // mat1[i][j] is a value...
            }
        }

        for (int i=0;i<3;i++) // accessing all the rows ...
        {                       // mat1[i] is an array 
            for(int j=0;j<3;j++) //accessing all the columns...
            {
                System.out.print(mat1[i][j]+" ");
            }
            System.out.println();
        }
    }
}
