create or replace trigger transaction_trigger after insert or update or delete on central_bank for each row
declare
	laccno central_bank.accno%type;
	lbalance central_bank.balance%type;
	diff number(12,2);
begin
	laccno := :new.accno;
	lbalance := :new.balance;
	
	if laccno > 0 then
		if inserting then
			insert into bank_transac_log values (laccno, 'New Account', null, lbalance, sysdate);
		elsif updating then
			diff := :new.balance - :old.balance;
			if diff < 0 then
				insert into bank_transac_log values (laccno, 'Withdraw', diff, lbalance, to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss'));
			else
				insert into bank_transac_log values (laccno, 'Deposit', diff, lbalance, sysdate);
			end if;
		elsif deleting then
			insert into bank_transac_log values (laccno, 'Account Closing', lbalance, null, sysdate);
		end if;
	end if;
end;
/
