create or replace function central_transfer(vaccno number,taccno number,vtransfer number,vpin number) return boolean is

vbalance number(10,2);
tbalance number(10,2);
cpin number(4);

begin
	select pin,balance into cpin,vbalance from central_bank where accno=vaccno;
	select balance into tbalance from central_bank where accno=taccno;
	if cpin=vpin and vbalance>=vtransfer then
		update central_bank set balance=vbalance-vtransfer where accno=vaccno;
		update central_bank set balance=tbalance+vtransfer where accno=taccno;
		return true;
	else
		return false;
	end if;
end;
/