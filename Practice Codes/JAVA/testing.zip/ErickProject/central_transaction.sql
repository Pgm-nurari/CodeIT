clear screen
set serveroutput on

declare
	vaccno central_bank.accno%type;
	taccno central_bank.accno%type;
	vpin central_bank.pin%type;
	vamount number(10,2);
	choice varchar(2);

begin
	choice:='&D_Deposit_W_Withdraw_T_Transfer';
	vaccno:=&Your_acc_no;
	vpin:=&Pin_number;
	vamount:=&amount;
	case choice
		when 'D' then
			if central_deposit(vaccno,vamount,vpin) then
				dbms_output.put_line('Amount deposited');
			else
				dbms_output.put_line('Insufficient Balance');
			end if;
		when 'W' then
			if central_withdraw(vaccno,vamount,vpin) then
				dbms_output.put_line('Amount debited');
			else
				dbms_output.put_line('Insufficient Balance');
			end if;
		when 'T' then
			taccno:=&Recievers_acc_no;
			if central_transfer(vaccno,taccno,vamount,vpin) then
				dbms_output.put_line('Successfully Transferred');
			else
				dbms_output.put_line('Insufficient Balance');
			end if;
	end case;

exception
	when others then
		dbms_output.put_line('Account does not exist');
end;
/