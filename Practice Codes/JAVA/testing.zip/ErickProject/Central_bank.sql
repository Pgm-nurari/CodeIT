create table bank_details(ifsc varchar(10) primary key,bank_name varchar(25));

create table central_bank(accno number(12) primary key,ac_name varchar(15),balance number(10,2),pin number(4),ifsc varchar(10) references bank_details(ifsc));



insert into bank_details values('SBIN','State Bank of India');
insert into bank_details values('CN','Canara');
insert into bank_details values('FN','Federal');
insert into bank_details values('SIN','South Indian');




insert into central_bank values(4568915,'Kiran',45000,3625,'CN'); 
insert into central_bank values(4568945,'Erick',96000,2589,'FN');
insert into central_bank values(4568989,'Meenakshi',55000,1534,'CN');
insert into central_bank values(4568948,'Narayanan',89000,1489,'FN');
insert into central_bank values(4568947,'Gopi',96000,2496,'CN');
insert into central_bank values(4568568,'Gowri',78000,8641,'SIN');
insert into central_bank values(4568478,'Niranjana',76000,4785,'SIN');
insert into central_bank values(4568923,'Jesine',88000,3654,'SBIN');
insert into central_bank values(4568979,'Chandranibha',78000,2598,'SIN');
insert into central_bank values(4568973,'Gayathri',63000,7895,'FN');
insert into central_bank values(4568921,'Devananda',77000,2674,'SBIN');
insert into central_bank values(4568989,'Vishnu',55000,1679,'CN');
insert into central_bank values(4568912,'Rohan',49000,3624,'SIN');
insert into central_bank values(4568999,'Suraj',78000,7931,'FN');
insert into central_bank values(4568973,'Sabhyam',99000,2513,'CN');
insert into central_bank values(4568100,'Erick',100000,3644,'SBIN');
insert into central_bank values(4565239,'Kiran',60000,1234,'SBIN');
insert into central_bank values(4568364,'Gowri',62000,2234,'SBIN');
insert into central_bank values(4536978,'Chandranibha',75000,5665,'SBIN');