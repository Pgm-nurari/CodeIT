set serveroutput on
set feedback off
set verify off

declare
  v_name varchar2(50);
  v_age number;
begin
  dbms_output.put_line('Please enter your name:');
  dbms_output.new_line;
  execute immediate 'prompt';
  execute immediate 'accept name';

  dbms_output.put_line('Please enter your age:');
  dbms_output.new_line;
  execute immediate 'prompt';
  execute immediate 'accept age number';

  -- Introduce a delay to simulate flushing the output
  dbms_lock.sleep(1);

  dbms_output.put_line('Name: ' || '&name');
  dbms_output.put_line('Age: ' || '&age');
end;
/
