create or replace function central_deposit(vaccno number,vdeposit number,vpin number) return boolean is

vbalance number(10,2);
cpin number(10,2);

begin
	select pin,balance into cpin,vbalance from central_bank where accno=vaccno;
	if cpin=vpin then
		update central_bank set balance=vbalance+vdeposit where accno=vaccno;
		return true;
	else
		return false;
	end if;
end;
/